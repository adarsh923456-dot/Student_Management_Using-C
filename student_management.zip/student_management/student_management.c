#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 
// ─────────────────────────────────────────
//  STRUCT DEFINITION
// ─────────────────────────────────────────
 
typedef struct Student {
    int roll;
    char name[50];
    float marks;
    struct Student* next;   // pointer to the next node
} Student;
 
// Head of the linked list (starts empty)
Student* head = NULL;
 
// ─────────────────────────────────────────
//  1. ADD A STUDENT
// ─────────────────────────────────────────
 
void addStudent(int roll, char* name, float marks) {
    // Allocate memory for new node
    Student* newStudent = (Student*)malloc(sizeof(Student));
    if (newStudent == NULL) {
        printf("Memory allocation failed!\n");
        return;
    }
 
    // Fill in the data
    newStudent->roll  = roll;
    strncpy(newStudent->name, name, 49);
    newStudent->marks = marks;
    newStudent->next  = NULL;
 
    // If list is empty, new node becomes head
    if (head == NULL) {
        head = newStudent;
    } else {
        // Otherwise, walk to the end and attach
        Student* temp = head;
        while (temp->next != NULL)
            temp = temp->next;
        temp->next = newStudent;
    }
    printf("Student '%s' added successfully!\n", name);
}
 
// ─────────────────────────────────────────
//  2. DISPLAY ALL STUDENTS
// ─────────────────────────────────────────
 
void displayAll() {
    if (head == NULL) {
        printf("No student records found.\n");
        return;
    }
 
    printf("\n%-10s %-20s %-10s\n", "Roll No", "Name", "Marks");
    printf("─────────────────────────────────────\n");
 
    Student* temp = head;
    while (temp != NULL) {
        printf("%-10d %-20s %-10.2f\n", temp->roll, temp->name, temp->marks);
        temp = temp->next;
    }
    printf("\n");
}
 
// ─────────────────────────────────────────
//  3. SEARCH BY ROLL NUMBER
// ─────────────────────────────────────────
 
void searchStudent(int roll) {
    Student* temp = head;
    while (temp != NULL) {
        if (temp->roll == roll) {
            printf("\nFound! Roll: %d | Name: %s | Marks: %.2f\n",
                   temp->roll, temp->name, temp->marks);
            return;
        }
        temp = temp->next;
    }
    printf("Student with roll number %d not found.\n", roll);
}
 
// ─────────────────────────────────────────
//  4. DELETE BY ROLL NUMBER
// ─────────────────────────────────────────
 
void deleteStudent(int roll) {
    if (head == NULL) {
        printf("List is empty.\n");
        return;
    }
 
    Student* temp = head;
    Student* prev = NULL;
 
    // Check if head itself is the target
    if (temp->roll == roll) {
        head = temp->next;
        free(temp);
        printf("Student with roll %d deleted.\n", roll);
        return;
    }
 
    // Walk the list to find the node
    while (temp != NULL && temp->roll != roll) {
        prev = temp;
        temp = temp->next;
    }
 
    if (temp == NULL) {
        printf("Student with roll %d not found.\n", roll);
        return;
    }
 
    prev->next = temp->next;
    free(temp);
    printf("Student with roll %d deleted.\n", roll);
}
 
// ─────────────────────────────────────────
//  5. FREE ALL MEMORY (cleanup)
// ─────────────────────────────────────────
 
void freeAll() {
    Student* temp = head;
    while (temp != NULL) {
        Student* next = temp->next;
        free(temp);
        temp = next;
    }
    head = NULL;
}
 
// ─────────────────────────────────────────
//  MAIN MENU
// ─────────────────────────────────────────
 
int main() {
    int choice, roll;
    char name[50];
    float marks;
 
    while (1) {
        printf("\n===== Student Record System =====\n");
        printf("1. Add Student\n");
        printf("2. Display All Students\n");
        printf("3. Search Student\n");
        printf("4. Delete Student\n");
        printf("5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
 
        switch (choice) {
            case 1:
                printf("Enter Roll Number: ");
                scanf("%d", &roll);
                printf("Enter Name: ");
                scanf(" %[^\n]", name);   // reads full name with spaces
                printf("Enter Marks: ");
                scanf("%f", &marks);
                addStudent(roll, name, marks);
                break;
 
            case 2:
                displayAll();
                break;
 
            case 3:
                printf("Enter Roll Number to search: ");
                scanf("%d", &roll);
                searchStudent(roll);
                break;
 
            case 4:
                printf("Enter Roll Number to delete: ");
                scanf("%d", &roll);
                deleteStudent(roll);
                break;
 
            case 5:
                freeAll();
                printf("Goodbye!\n");
                return 0;
 
            default:
                printf("Invalid choice. Try again.\n");
        }
    }
}